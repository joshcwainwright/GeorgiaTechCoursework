Name: Joshua Wainwright
Class: CS 2110
Game: Adventure Time Mini game

Controls:
1. up arrow = move up
2. down arrow = move down
3. left arrow = move left
4. right arrow = move right
5. start(enter) = start playing
6. select(backspace) = restart

Goal:
The goal of my game is to survive as long as possible as the lumpy space princess. Making any contact with the ice
king will result in a loss. The game keeps track of the high score of each session, which is displayed after each round.
Players can use the select key to return to the start screen at any time. Every 5 seconds, the speed of the player and
enemy will increase. The score is displayed in the bottom left corner.
