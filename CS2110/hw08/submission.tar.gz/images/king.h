/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x30 king king.png 
 * Time-stamp: Monday 04/04/2022, 18:18:51
 * 
 * Image Information
 * -----------------
 * king.png 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef KING_H
#define KING_H

extern const unsigned short king[900];
#define KING_SIZE 1800
#define KING_LENGTH 900
#define KING_WIDTH 30
#define KING_HEIGHT 30

#endif

