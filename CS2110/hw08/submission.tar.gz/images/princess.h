/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=22x30 princess princess.png 
 * Time-stamp: Monday 04/04/2022, 18:07:20
 * 
 * Image Information
 * -----------------
 * princess.png 22@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PRINCESS_H
#define PRINCESS_H

extern const unsigned short princess[660];
#define PRINCESS_SIZE 1320
#define PRINCESS_LENGTH 660
#define PRINCESS_WIDTH 22
#define PRINCESS_HEIGHT 30

#endif

